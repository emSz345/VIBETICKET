const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Cadastro de usuário
router.post('/register', async (req, res) => {
  const { nome, email, senha, provedor } = req.body;

  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: 'Usuário já existe' });

    const newUser = new User({ nome, email, senha, provedor });
    await newUser.save();

    res.status(201).json({ message: 'Usuário cadastrado com sucesso', user: newUser });
  } catch (err) {
    res.status(500).json({ message: 'Erro ao cadastrar usuário', error: err.message });
  }
});

module.exports = router;
